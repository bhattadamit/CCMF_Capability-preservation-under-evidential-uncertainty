# Replication package: CCMF (Capability-Contract Migration Framework) manuscript

Companion to the manuscript "Capability preservation under evidential uncertainty: a design theory and governance framework for evidence-aware enterprise modernization" (revised version, Nov 2026). Author, affiliation and repository DOI are placeholders: [DOI to be inserted on deposit].

## What this package is, and is not
- It reproduces every *derived* number in the manuscript: the model-level verification counts (Table 8), the worked example (Section 7.3, Tables 9 and 10) and the non-inferiority sample sizes (Table 11 and its sensitivity cases).
- These are **model-level** results. They check internal consistency of the formal model against a brute-force oracle. They are **not** empirical evidence about real migrations. No real case data are included, because none has been collected (see manuscript Section 8.7 and Appendix E).
- It does **not** contain the "Conversion Weekends" study (consumer complaints at bank-merger conversion dates). That is a separate paper; its data and results were not available when this package was built. See `CONVERSION_WEEKENDS_NOTE.md`.

## Contents
- `code/ccmf_spec.py` - reference executable specification (manuscript Supplementary S1), standard library only.
- `results/verification_results.json` - output of the full run (Supplementary S2).
- `results/worked_example_output.txt` - output of `--example`.
- `data/table_model_level_verification.csv` - counts behind Table 8.
- `data/table_sample_size_noninferiority.csv` - sample sizes behind Table 11 (one-sided alpha 0.025, power 0.80).
- `logs/run_stdout.txt` - console output of the full run.
- `CHECKSUMS.sha256` - SHA-256 of every file.

## Reproduce
```
cd code
python3 ccmf_spec.py            # about 1 minute; writes verification_results.json in the current directory
python3 ccmf_spec.py --example  # worked example of Section 7.3
```
Seeds are fixed (random n=2: seed 11, N=100,000; random n=3: seed 12, N=40,000). A rerun in the build environment produced a file byte-identical to `results/verification_results.json`.

## Expected key results
Exhaustive n=2 (262,144 instances): 0 violations of any checked property. Random n=2 (100,000) and n=3 (40,000): 0 violations. Sample size for p=0.10, margin 0.05: 566 per arm.

## Licence and citation
Licence: [choose before deposit, e.g. MIT for code, CC BY 4.0 for data]. Cite the manuscript and the repository DOI once assigned.
